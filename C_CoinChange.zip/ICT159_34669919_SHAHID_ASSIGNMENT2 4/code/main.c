/* 

AUTHOR: ZAINA SHAHID

ASSIGNMENT-2 ICT159 

DATE: 27th July 2023


*/



#include <stdio.h>
#include <string.h>  //the required libraries 
#include <stdlib.h>
#include "currency.h"


/*  ASSUMPTIONS 

  - The Program will calculate the change in each currencies and
    display the result once the users enters a name

  - If the name is not present in our records, the program will
    will display Name not found and display the menu again

*/

/*  ISSUES 

  - After running the program, the menu is appears twice after which the user 
    enter the name
*/


//this is the main function
int main()
{

  //declaring the variaabels
   
   int option = 0;  //for menu choice 
   int recordCount = 0; // Variable to keep track of the number of records in the array


   //dynamic allocation of array using the malloc function 

   record* records = (record*)malloc(10 * sizeof(record)); // Allocate memory for 10 records

   //function is called to set initial values for each record.

   InitializeRecords(records, 10);

   //opening the file 
   //fptr is the file pointer for the coins.txt file

   	FILE* fptr = fopen("coins.txt", "r");  //r for read mode 
	if (fptr == NULL)
	{
		printf("Input file could not be opened\n");
        void ReleaseRecords(record* records); // Free the dynamically allocated                                       // memory before returning
        
		return -1;
	} else {
        printf("Input file opened\n");
    }

    //reading the file
    recordCount = readFile(fptr, records, 10);
    fclose(fptr); //closing the file 
;

    
    do {
        option = ConsoleMenu(); //calling the menu function

        if (option == 1) {
            InputName(records, recordCount); //This function will ask the user to input a name
            // Increment recordCount after successfully adding a record.
            if (recordCount < 10) {
                recordCount++;
            } else {
                printf("No more space to add records.\n");
            }
        }
    } while (option != 2);

        

    //opening output file 
    //outptr is the file pointer for change.csv file 

    FILE* outptr = fopen("change.csv", "w"); //w mode for writing 
	 if (outptr == NULL)
	    {
		   printf("Output file could not be opened\n");
           free(records); // Free the dynamically allocated memory before returning
           return -1;
	    } else {
            printf("Output file opened\n");
        }

        //calling the function to write in the file 
        WriteToFile(outptr, records, recordCount);	
	
	    fclose(outptr); //closing the file 

        void ReleaseRecords(record* records); // Free the dynamically allocated                                       // memory before the program ends
        return 0;


  



}
