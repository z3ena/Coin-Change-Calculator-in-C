//this is the header file which contain all the 
//defined prototypes for this code and the function declarations

#ifndef CURRENCY_H
#define CURRENCY_H

typedef struct record
{
    char name[30];
    int centsUS;
    int centsAUS;
    int centsEUR;
} record;

//function for ALLOCATING 
void InitializeRecords(record array[], int length);

//function for READING  
int readFile(FILE* fileptr, record records[], int length);

//function for SEARCHING THE RECORD 
int SearchRecords(record records[], int length, char name[30]);

//function for CALCULATION 
void CalculateCents(int* cents, int* coins, int den);

//function INPUT NAME from the USER 
//and printing the corrosponding record
void InputName(record records[], int count);

//MENU FUNCTION
int ConsoleMenu();

//function for WRITING in OUTPUT file
void WriteToFile(FILE* fileptr, record records[], int length);

//function for FREEING the memory
void ReleaseRecords(record* records);

#endif // CURRENCY_H

