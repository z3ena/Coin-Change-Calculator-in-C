//This is the function file


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "currency.h"

//function for ALLOCATING 

//takes an array of record structures and its length as parameters.

void InitializeRecords(record array[], int length)
{
    for (int i = 0; i < length; i++)
    {
        memset(array[i].name, 0, sizeof(array[i].name)); // Set the 'name' field to an empty string (all bytes to 0)
        array[i].centsUS = 0;
        array[i].centsAUS = 0;
        array[i].centsEUR = 0;
    }
}

//function for READING  

//for reading data from the file pointed to by fileptr and storing it in the records array.

int readFile(FILE* fileptr, record records[], int length)
{
	char name[30] = {'\0'};
	char temp[30] = {'\0'};
    char temp2[30] = {'\0'};
	char curr[30] = {'\0'};
	int coins = 0, i = 0;
	
	while (fscanf(fileptr, "%s %d %s %s %s", name, &coins, temp, temp2, curr) != EOF && i < length)
	{
		int index = SearchRecords(records, length, name);
        if (index != -1)
        {
            if (strcmp(curr, "US") == 0)
            {
                records[index].centsUS += coins;
            }
            else if (strcmp(curr, "AUS") == 0)
            {
                records[index].centsAUS += coins;
            }
            else if (strcmp(curr, "EUR") == 0)
            {
                records[index].centsEUR += coins;
            }
        }
        else
        {
            strcpy(records[i].name, name);
            if (strcmp(curr, "US") == 0)
            {
                records[i].centsUS = coins;
            }
            else if (strcmp(curr, "AUS") == 0)
            {
                records[i].centsAUS = coins;
            }
            else if (strcmp(curr, "EUR") == 0)
            {
                records[i].centsEUR = coins;
            }
            i++;
        }
	}
	
	return i;
}

//function for SEARCHING THE RECORD 

//checking name and currency 
//returns the index of the record if found, otherwise, it returns -1.
int SearchRecords(record records[], int length, char name[30])
{
	int index = -1;
	for (int i = 0; i < length; i++)
	{
		if (strcmp(records[i].name, name) == 0)
		{
			index = i;
		}
	}
	return index;
}


//function for CALCULATION 


//calculates the number of coins (whole units) and 
//remaining cents after dividing the value stored in cents by the given den.
void CalculateCents(int* cents,  int* coins, int den)
{
	*coins = (*cents / den);
	*cents %= den;	 //result is stored back in cents and coins using pointers
}


//function INPUT NAME from the USER 

// This function will ask the user to input a name.
// displays the corresponding record's currency data.
void InputName(record records[], int count)
{
    char name[30];
    int option = 1; // Set the option to 1 (default value) to enter the loop.

    if (count > 0)
    {
        option = ConsoleMenu(); // Display the menu only if there are records in the array.
    }

    if (option == 1) // Proceed to get the name if option is 1.
    {
        printf("\nEnter name: ");
        scanf("%s", name);

         printf("Records count: %d\n", count);
        for (int i = 0; i < count; i++)
        {
            printf("Record %d: %s\n", i, records[i].name);
        }



        int index = SearchRecords(records, count, name);
        if (index != -1)
        {
            printf("Name: %s\n", records[index].name);

            // Check if the record has any currency data and print it accordingly
            if (records[index].centsUS > 0)
            {
                printf("US: %d\n", records[index].centsUS);
                int cents = records[index].centsUS;
                int change_50, change_25, change_10, change_1;
                CalculateCents(&cents, &change_50, 50);
                CalculateCents(&cents, &change_25, 25);
                CalculateCents(&cents, &change_10, 10);
                CalculateCents(&cents, &change_1, 1);
                printf("Change in US currency: %d 50c,\n", change_50);
                printf("%d 25c,\n", change_25);
                printf("%d 10c,\n", change_10);
                printf("%d 1c\n", change_1);

               
            }
            if (records[index].centsAUS > 0)
            {
                printf("AUS: %d\n", records[index].centsAUS);
                int cents = records[index].centsAUS;
                int change_50, change_20, change_10, change_5;
                CalculateCents(&cents, &change_50, 50);
                CalculateCents(&cents, &change_20, 20);
                CalculateCents(&cents, &change_10, 10);
                CalculateCents(&cents, &change_5, 5);
                printf("Change in Australian currency: %d 50c,\n", change_50);
                printf("%d 20c,\n", change_20);
                printf("%d 10c,\n", change_10);
                printf("%d 5c\n", change_5);

                
            }
            if (records[index].centsEUR > 0)
            {
                printf("EUR: %d\n", records[index].centsEUR);
                int cents = records[index].centsEUR;
                int change_50, change_20, change_10, change_5, change_1;
                CalculateCents(&cents, &change_50, 50);
                CalculateCents(&cents, &change_20, 20);
                CalculateCents(&cents, &change_10, 10);
                CalculateCents(&cents, &change_5, 5);
                CalculateCents(&cents, &change_1, 1);
                printf("Change in Euro currency: %d 50c,\n", change_50);
                printf("%d 20c,\n", change_20);
                printf("%d 10c,\n", change_10);
                printf("%d 5c,\n", change_5);
                printf("%d 1c\n", change_1);

                
            }
        }
        else
        {
            printf("Name not found in records.\n");
        }
    }
}




//MENU FUNCTION

//displays a simple menu to the user with two options: "Enter name" and "Exit".
int ConsoleMenu() {

    int option = 0;
	char invalid_ch;
   
	printf("\n1. Enter name \n2. Exit \n");
	printf("\nOption selected: ");
	scanf("%d",&option);
	scanf("%c",&invalid_ch);
 
    return option;

}
//function for WRITING in OUTPUT file

//writes the currency data from the records array into the file pointed to by fileptr
//calculates the number of coins of different denominations using the CalculateCents function
// and writes the data to the file in a formatted way


void WriteToFile(FILE* fileptr, record records[], int length)
{
	int change_50, change_25, change_20, change_10, change_5, change_1;
    for (int i = 0; i < length; i++) {
        if (records[i].centsUS != 0)
        {
            int cents = records[i].centsUS;
            CalculateCents(&cents, &change_50, 50);
            CalculateCents(&cents, &change_25, 25);
            CalculateCents(&cents, &change_10, 10);
            CalculateCents(&cents, &change_1, 1);
            fprintf(fileptr, "%s, the change for %d cents in US$ is %d,%d,%d,%d\n", records[i].name, records[i].centsUS, change_50, change_25, change_10, change_1);
        }
        if (records[i].centsAUS != 0)
        {
            int cents = records[i].centsAUS;
            CalculateCents(&cents, &change_50, 50);
            CalculateCents(&cents, &change_20, 20);
            CalculateCents(&cents, &change_10, 10);
            CalculateCents(&cents, &change_5, 5);
            fprintf(fileptr, "%s, the change for %d cents in AU$ is %d,%d,%d,%d\n", records[i].name, records[i].centsAUS, change_50, change_20, change_10, change_5);
        }
        if (records[i].centsEUR != 0)
        {
            int cents = records[i].centsEUR;
            CalculateCents(&cents, &change_50, 50);
            CalculateCents(&cents, &change_20, 20);
            CalculateCents(&cents, &change_10, 10);
            CalculateCents(&cents, &change_5, 5);
            fprintf(fileptr, "%s, the change for %d cents in EUR is %d,%d,%d,%d\n", records[i].name, records[i].centsEUR, change_20, change_10, change_5, change_1);
        }
    }
    
}
//function for FREEING the memory

// This function will release and free the dynamically allocated memory for records
void ReleaseRecords(record* records)
{
    free(records);
}